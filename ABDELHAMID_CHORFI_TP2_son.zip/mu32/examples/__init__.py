"""
    BeamSensing Mu32 Module
    Content :
	- program examples
"""
