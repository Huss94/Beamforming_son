
import mu32.core

print( 'This is Mu32 program' )

mu32.core.__main__()

